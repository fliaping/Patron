package com.deepwits.Patron.Recorder;

import android.hardware.Camera;
import android.util.Log;

/**
 * Created by Payne on 1/15/16.
 */
public class TestCallback implements Camera.PreviewCallback {
    @Override
    public void onPreviewFrame(byte[] data, Camera camera) {
        Log.e("testcameara","onPreviewFrame");
    }
}
