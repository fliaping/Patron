package com.deepwits.Patron.Recorder;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.widget.Toast;

import com.deepwits.Patron.R;

public class MainActivity extends AppCompatActivity {

    private SurfaceView mRecordSurfaceView;
    private SurfaceHolder mRecordSurfaceHolder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        mRecordSurfaceView = (SurfaceView) findViewById(R.id.surface);  //预览显示的surface
        mRecordSurfaceHolder = mRecordSurfaceView.getHolder();

        final CameraManager cameraManager = new CameraManager(this,mRecordSurfaceHolder);

        findViewById(R.id.start).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cameraManager.openCamera();
            }
        });
        findViewById(R.id.stop).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cameraManager.releaseCamera();
            }
        });
        findViewById(R.id.rec).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cameraManager.startRecord();
                Toast.makeText(getApplicationContext(),"rec",Toast.LENGTH_SHORT).show();
            }
        });
        findViewById(R.id.rec_st).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cameraManager.stopRecord();
                Toast.makeText(getApplicationContext(),"rec_stops",Toast.LENGTH_SHORT).show();
            }
        });

    }



}
