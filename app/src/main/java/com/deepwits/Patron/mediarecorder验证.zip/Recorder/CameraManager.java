package com.deepwits.Patron.Recorder;

import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.ImageFormat;
import android.hardware.Camera;
import android.media.MediaRecorder;
import android.util.Log;
import android.view.SurfaceHolder;

import java.io.IOException;
import java.util.List;


/**
 * Created by Payne on 1/15/16.
 */
public class CameraManager {
    private final String TAG = "CameraManager";
    private Context mService = null;
    private Camera.Parameters parameters; //相机属性
    private int cameraId = Camera.CameraInfo.CAMERA_FACING_BACK;   //相机ID
    private Camera mCamera = null;  //相机实例对象
    private byte[] frameBuffer;     //预览缓存空间
    private TestCallback mEncoder = null;
    private MediaRecorder mMediaRecorder = null;
    private SurfaceHolder mSurfaceHolder;

    public CameraManager(Context mService,SurfaceHolder mSurfaceHolder){
        this.mService = mService;
        this.mSurfaceHolder = mSurfaceHolder;
        mEncoder = new TestCallback();
        addSurfaceCallback();
    }

    public synchronized void startRecord(){
        //openCamera();
        prepareMeidaRecorder();

        mMediaRecorder.start();
        mCamera.setPreviewCallback(mEncoder);
    }
    public synchronized void stopRecord(){
        releaseMediaRecorder();
    }

    private void addSurfaceCallback(){
        mSurfaceHolder.addCallback(new SurfaceHolder.Callback() {
            @Override
            public void surfaceCreated(SurfaceHolder holder) {
                Log.e("surface", "surfaceCreated");
                //mCamera.setPreviewCallback(mEncoder);
            }

            @Override
            public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
                Log.e("surface","surfaceChanged");
               /* if (mSurfaceHolder.getSurface() == null){
                    return;
                }

                try {
                    mCamera.stopPreview();
                } catch (Exception e){
                    // ignore: tried to stop a non-existent preview
                }

                try {
                    mCamera.setPreviewCallback(mEncoder);
                    mCamera.setPreviewDisplay(mSurfaceHolder);
                    mCamera.startPreview();

                } catch (Exception e){
                    Log.d(TAG, "Error starting camera preview: " + e.getMessage());
                }*/
            }

            @Override
            public void surfaceDestroyed(SurfaceHolder holder) {
                Log.e("surface","surfaceDestroyed");

            }
        });
    }

    //打开相机，获取相机预览
    public synchronized   boolean openCamera() {
        boolean qOpened = false;
        if (checkCameraHardware()) {
            Log.e(TAG, "OpenInView cameraId = " + (cameraId));
            mCamera = getCameraInstance();//来获得一个camera对象的实例
            if (mCamera != null) {
                try {
                    Camera.Size size = parameters.getPreviewSize();
                    frameBuffer = new byte[size.width * size.height * 3 / 2]; //申请空间
                    //mCamera.setDisplayOrientation(180);
                    //mCamera.addCallbackBuffer(frameBuffer);  //每一帧
                    mCamera.setPreviewDisplay(mSurfaceHolder);//连接到SurfaceView
                    mCamera.setPreviewCallback(mEncoder);
                    //mCamera.setPreviewCallbackWithBuffer(new TestCallback()); //设置回调
                    mCamera.startPreview();//开始显示实时摄像画面
                } catch (IOException e) {
                    Log.e(TAG, e.getMessage(), e);
                }
                qOpened = (mCamera != null);
            } else {
            }
        }

        return qOpened;
    }

    //准备录像
    private boolean prepareMeidaRecorder() {
        Log.e(TAG, "prepareVideoRecorder");
        if (mCamera == null) {
            Log.e(TAG, "mCamera == null");
            return false;
        }
        mCamera.unlock();

        mMediaRecorder = new MediaRecorder();
        // Step 1: Unlock and set camera to MediaRecorder , Starting with Android 4.0 (API level 14), the Camera.lock() and Camera.unlock() calls are managed for you automatically.
        mMediaRecorder.setCamera(mCamera);

        //设置声音来源，一般传入 MediaRecorder. AudioSource.MIC参数指定录制来自麦克风的声音。
        mMediaRecorder.setAudioSource(MediaRecorder.AudioSource.CAMCORDER);//MediaRecorder.AudioSource.CAMCORDER);

        mMediaRecorder.setVideoSource(MediaRecorder.VideoSource.CAMERA);//设置视频来源

        // Step 3: Set a CamcorderProfile (requires API Level 8 or higher)
        // mMediaRecorder.setProfile(CamcorderProfile.get(CamcorderProfile.QUALITY_HIGH));

        mMediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);

        mMediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
        mMediaRecorder.setAudioChannels(2);
        mMediaRecorder.setAudioEncodingBitRate(64000);

        mMediaRecorder.setVideoEncoder(MediaRecorder.VideoEncoder.H264);

        // 设置视频录制的分辨率。必须放在设置编码和格式的后面，否则报错
        //mMediaRecorder.setVideoSize(1280, 720);
        mMediaRecorder.setVideoSize(1920, 1080);

        // 设置录制的视频帧率。必须放在设置编码和格式的后面，否则报错

        mMediaRecorder.setVideoFrameRate(30);  //帧率


        mMediaRecorder.setVideoEncodingBitRate(1024 * 1024 * 8);

        // Step 4: Set output file
        mMediaRecorder.setOutputFile(mService.getExternalFilesDir("patron").getAbsolutePath()+"/xx.mp4");//直接保存为文件时的路径
        Log.e("testcameara",mService.getExternalFilesDir("patron").getAbsolutePath());
        // Step 5: Set the preview output
        //mMediaRecorder.setPreviewDisplay(mSurfaceHolder.getSurface());

        // Step 6: Prepare configured MediaRecorder
        try {
            mMediaRecorder.prepare();
            Log.e(TAG, "mMediaRecorder.prepare.....");

        } catch (IllegalStateException e) {
            Log.e("v recorder", "IllegalStateException preparing MediaRecorder: " + e.getMessage());
            releaseMediaRecorder();
            return false;
        } catch (IOException e) {
            Log.e("v recorder", "IOException preparing MediaRecorder: " + e.getMessage());
            releaseMediaRecorder();
            return false;
        }

        return true;
    }
    //释放mediaRecorder
    private void releaseMediaRecorder() {
        Log.e(TAG, "releaseMediaRecorder");
        if (mMediaRecorder != null) {
            mMediaRecorder.reset();   // clear recorder configuration
            mMediaRecorder.release(); // release the recorder object
            mMediaRecorder = null;
            if (mCamera != null) {
                //mCamera.setPreviewCallback(mEncoder);
                //mCamera.lock(); // lock camera for later use
            }
        }
    }



    //检测是否有摄像头
    private boolean checkCameraHardware() {
        Context context = mService.getApplicationContext();
        if (context.getPackageManager().hasSystemFeature(PackageManager.FEATURE_CAMERA)) {
            return true;
        } else {
            return false;
        }
    }
    //获得camera实例，配置参数 parameters
    private Camera getCameraInstance() {
        Log.e(TAG, "getCameraInstance.....");
        Camera c = null;
        //Camera c2 = null;
        try {
            c = Camera.open(cameraId);
            parameters = c.getParameters(); //配置参数
            List<Camera.Size> si = parameters.getSupportedPreviewSizes();
            for (int i = 0; i < si.size(); i++) {
                Log.d(TAG, "摄像头" + cameraId + "支持：" + si.get(i).width + "*" + si.get(i).height);
            }

            c.setParameters(parameters);
            Log.e(TAG, "PreviewSize:" + c.getParameters().getPreviewSize().width + " X " + c.getParameters().getPreviewSize().height);
        } catch (Exception e) {
            Log.e(TAG, "相机"+cameraId+"实例化失败...");
            Log.e(TAG, e.getMessage(), e);
        }
        return c;
    }
    /**
     * Clear any existing preview / camera.
     */
    public void releaseCamera() {
        if (mCamera != null) {
            mCamera.stopPreview();
            mCamera.release();
            mCamera = null;
        }
    }
    //some get&set method in CameraManager  class
    //-------set------------
    public void setCameraId(int cameraId){
        this.cameraId = cameraId;
    }
    public void setParameters(Camera.Parameters parameters){
        this.parameters = parameters;
    }
    //--------get-------
    public int getCameraId(){
        return this.cameraId;
    }
    public Camera.Parameters getParameters(){
        return this.parameters;
    }
    //----END-----  some get&set method in CameraManager  class
}
